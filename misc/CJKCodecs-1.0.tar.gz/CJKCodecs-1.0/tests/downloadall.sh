#!/bin/sh
# $Id: downloadall.sh,v 1.1 2003/06/05 10:23:58 perky Exp $
python testall.py|sed -n -e 's,^.*\(http[^ ]*\).*$,\1,p'|xargs -n1 wget
